import sys, os
sys.path.append("C:\\Users\\wkdal\\Desktop\\All_File\\2023\\03. 수업\\딥러닝 프로그래밍\\deep-learning-from-scratch-master")
import numpy as np
import matplotlib.pyplot as plt
from dataset.mnist import load_mnist
# coding: utf-8
#import sys, os
# dataset 모듈이 있는 경로를 지정
#dataset_path = "C:\\Users\\wkdal\\Desktop\\All_File\\2023\\03. 수업\\딥러닝 프로그래밍\\deep-learning-from-scratch-master\\dataset"
#sys.path.append("C:\\Users\\wkdal\\Desktop\\All_File\\2023\\03. 수업\\딥러닝 프로그래밍\\deep-learning-from-scratch-master\\dataset")  # 현재 스크립트의 부모 디렉토리를 Python 모듈 경로에 추가
import numpy as np
import matplotlib.pyplot as plt  # 맷플롯립의 pyplot 모듈을 plt라는 이름으로 가져오기
from dataset.mnist import load_mnist  # MNIST 데이터셋을 로드하기 위한 함수 가져오기
from common.multi_layer_net_extend import MultiLayerNetExtend  # 확장된 다층 신경망 클래스 가져오기
from common.optimizer import SGD, Adam  # SGD와 Adam 최적화 알고리즘 클래스 가져오기

(x_train, t_train), (x_test, t_test) = load_mnist(normalize=True)  # MNIST 데이터셋을 로드하고 정규화

# 학습 데이터를 줄임
x_train = x_train[:1000]  # 훈련 데이터를 1000개로 제한
t_train = t_train[:1000]  # 훈련 라벨을 1000개로 제한

max_epochs = 20  # 최대 에폭 수 설정
train_size = x_train.shape[0]  # 훈련 데이터 크기
batch_size = 100  # 배치 크기
learning_rate = 0.01  # 학습률


# 훈련 함수 정의
def __train(weight_init_std):
    # 배치 정규화를 사용하는 신경망과 사용하지 않는 신경망 초기화
    bn_network = MultiLayerNetExtend(input_size=784, hidden_size_list=[100, 100, 100, 100, 100], output_size=10,
                                     weight_init_std=weight_init_std, use_batchnorm=True)
    network = MultiLayerNetExtend(input_size=784, hidden_size_list=[100, 100, 100, 100, 100], output_size=10,
                                  weight_init_std=weight_init_std)
    optimizer = SGD(lr=learning_rate)  # SGD 최적화 알고리즘 초기화

    train_acc_list = []  # 일반 신경망의 정확도를 저장할 리스트
    bn_train_acc_list = []  # 배치 정규화 신경망의 정확도를 저장할 리스트

    iter_per_epoch = max(train_size / batch_size, 1)  # 에폭 당 반복 횟수
    epoch_cnt = 0  # 에폭 카운트

    # 훈련 반복
    for i in range(1000000000):
        batch_mask = np.random.choice(train_size, batch_size)  # 배치 마스크 생성
        x_batch = x_train[batch_mask]  # 배치 데이터
        t_batch = t_train[batch_mask]  # 배치 라벨

        # 두 신경망에 대해 그래디언트 계산 및 파라미터 업데이트
        for _network in (bn_network, network):
            grads = _network.gradient(x_batch, t_batch)
            optimizer.update(_network.params, grads)

        # 에폭마다 정확도 계산 및 출력
        if i % iter_per_epoch == 0:
            train_acc = network.accuracy(x_train, t_train)
            bn_train_acc = bn_network.accuracy(x_train, t_train)
            train_acc_list.append(train_acc)
            bn_train_acc_list.append(bn_train_acc)

            print("epoch:" + str(epoch_cnt) + " | " + str(train_acc) + " - " + str(bn_train_acc))

            epoch_cnt += 1
            if epoch_cnt >= max_epochs:
                break

    return train_acc_list, bn_train_acc_list


# 그래프 그리기==========
weight_scale_list = np.logspace(0, -4, num=16)  # 가중치 초기화 스케일 리스트
x = np.arange(max_epochs)  # x축 (에폭 수)

# 가중치 스케일에 따른 훈련 결과 시각화
for i, w in enumerate(weight_scale_list):
    print("============== " + str(i + 1) + "/16" + " ==============")
    train_acc_list, bn_train_acc_list = __train(w)  # 훈련 함수 호출

    plt.subplot(4, 4, i + 1)  # 서브플롯 설정
    plt.title("W:" + str(w))  # 서브플롯 제목
    # 배치 정규화 및 일반 신경망의 정확도 시각화
    if i == 15:
        plt.plot(x, bn_train_acc_list, label='Batch Normalization', markevery=2)
        plt.plot(x, train_acc_list, linestyle="--", label='Normal(without BatchNorm)', markevery=2)
    else:
        plt.plot(x, bn_train_acc_list, markevery=2)
        plt.plot(x, train_acc_list, linestyle="--", markevery=2)

    plt.ylim(0, 1.0)  # y축 범위 설정
    if i % 4:
        plt.yticks([])  # y축 눈금 설정
    else:
        plt.ylabel("accuracy")  # y축 라벨
    if i < 12:
        plt.xticks([])  # x축 눈금 설정
    else:
        plt.xlabel("epochs")  # x축 라벨
    plt.legend(loc='lower right')  # 범례 위치 설정

plt.show()  # 그래프 표시
