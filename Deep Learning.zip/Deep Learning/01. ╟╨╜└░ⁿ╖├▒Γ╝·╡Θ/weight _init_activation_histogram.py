# coding: utf-8
import numpy as np  # numpy 라이브러리를 np로 축약하여 사용
import matplotlib.pyplot as plt  # matplotlib의 pyplot을 plt로 축약하여 사용


def sigmoid(x):
    return 1 / (1 + np.exp(-x))  # 시그모이드 활성화 함수 정의


def ReLU(x):
    return np.maximum(0, x)  # ReLU 활성화 함수 정의


def tanh(x):
    return np.tanh(x)  # 하이퍼볼릭 탄젠트 활성화 함수 정의


input_data = np.random.randn(1000, 100)  # 1000개의 데이터와 100개의 특성을 갖는 랜덤 배열 생성
node_num = 100  # 각 은닉층의 노드(뉴런) 수를 100개로 설정
hidden_layer_size = 5  # 은닉층의 개수를 5개로 설정
activations = {}  # 활성화 결과를 저장할 딕셔너리 초기화

x = input_data  # 입력 데이터를 x 변수에 할당

for i in range(hidden_layer_size):  # 은닉층의 개수만큼 반복
    if i != 0:
        x = activations[i - 1]  # 첫 번째 은닉층이 아니면 이전 층의 활성화 결과를 입력으로 사용

    # 가중치 초기화 방법을 변경하며 실험 가능
    w = np.random.randn(node_num, node_num) * 1  # 정규 분포를 따르는 랜덤한 가중치 초기화

    a = np.dot(x, w)  # 입력 데이터와 가중치의 행렬 곱셈

    # 활성화 함수 선택을 바꿔가며 실험 가능
    z = sigmoid(a)  # 활성화 함수를 통과시킨 결과

    activations[i] = z  # 활성화 결과를 딕셔너리에 저장

# 은닉층의 활성화 결과를 히스토그램으로 그리기
for i, a in activations.items():
    plt.subplot(1, len(activations), i + 1)  # 여러 그래프 중 현재 은닉층에 해당하는 위치에 그래프 그리기
    plt.title(str(i + 1) + "-layer")  # 각 그래프에 제목 추가
    if i != 0: plt.yticks([], [])  # 첫 번째 그래프를 제외하고 y축 레이블 제거
    plt.hist(a.flatten(), 30, range=(0, 1))  # 활성화 결과의 분포를 히스토그램으로 그리기

plt.show()  # 모든 그래프를 화면에 표시
