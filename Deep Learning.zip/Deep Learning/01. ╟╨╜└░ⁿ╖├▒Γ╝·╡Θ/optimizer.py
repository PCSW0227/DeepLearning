# coding: utf-8
import numpy as np  # NumPy 라이브러리를 임포트합니다. (다차원 배열 계산에 필요)

class SGD:
    """확률적 경사 하강법（Stochastic Gradient Descent）"""

    def __init__(self, lr=0.01):
        self.lr = lr  # SGD 클래스의 객체가 생성될 때 학습률(lr)을 초기화합니다.

    def update(self, params, grads):
        for key in params.keys():
            params[key] -= self.lr * grads[key]  # 각 파라미터를 해당 기울기의 학습률 곱만큼 감소시켜 업데이트합니다.

class Momentum:
    """모멘텀 SGD"""

    def __init__(self, lr=0.01, momentum=0.9):
        self.lr = lr  # Momentum 클래스의 객체가 생성될 때 학습률(lr)을 초기화합니다.
        self.momentum = momentum  # 모멘텀 값도 초기화합니다.
        self.v = None  # 속도(v)를 저장할 변수를 None으로 초기화합니다.

    def update(self, params, grads):
        if self.v is None:
            self.v = {}
            for key, val in params.items():
                self.v[key] = np.zeros_like(val)  # 처음 업데이트 시 각 파라미터에 대응하는 속도(v)를 0으로 초기화합니다.
        for key in params.keys():
            self.v[key] = self.momentum * self.v[key] - self.lr * grads[key]  # 속도를 업데이트합니다: 모멘텀 * 이전 속도 - 학습률 * 기울기
            params[key] += self.v[key]  # 파라미터에 업데이트된 속도를 적용합니다.

class Nesterov:
    """Nesterov's Accelerated Gradient (http://arxiv.org/abs/1212.0901)"""

    def __init__(self, lr=0.01, momentum=0.9):
        self.lr = lr  # Nesterov 클래스의 객체가 생성될 때 학습률(lr)을 초기화합니다.
        self.momentum = momentum  # 모멘텀 값을 초기화합니다.
        self.v = None  # 속도(v)를 저장할 변수를 None으로 초기화합니다.

    def update(self, params, grads):
        if self.v is None:
            self.v = {}
            for key, val in params.items():
                self.v[key] = np.zeros_like(val)  # 처음 업데이트 시 각 파라미터에 대응하는 속도(v)를 0으로 초기화합니다.
        for key in params.keys():
            self.v[key] *= self.momentum  # 기존 속도에 모멘텀을 곱합니다.
            self.v[key] -= self.lr * grads[key]  # 현재 기울기에 학습률을 곱한 값을 빼서 속도를 업데이트합니다.
            params[key] += self.momentum * self.momentum * self.v[key]  # 파라미터를 업데이트합니다: 모멘텀^2 * 속도
            params[key] -= (1 + self.momentum) * self.lr * grads[key]  # 추가적으로 현재 기울기를 고려하여 파라미터를 업데이트합니다.

class AdaGrad:
    """AdaGrad"""

    def __init__(self, lr=0.01):
        self.lr = lr  # AdaGrad 클래스의 객체가 생성될 때 학습률(lr)을 초기화합니다.
        self.h = None  # AdaGrad에서 사용할 h 변수를 None으로 초기화합니다.

    def update(self, params, grads):
        if self.h is None:
            self.h = {}
            for key, val in params.items():
                self.h[key] = np.zeros_like(val)  # 처음 업데이트 시 각 파라미터에 대응하는 h를 0으로 초기화합니다.
        for key in params.keys():
            self.h[key] += grads[key] * grads[key]  # 각 파라미터에 대한 기울기의 제곱을 h에 누적합니다.
            params[key] -= self.lr * grads[key] / (np.sqrt(self.h[key]) + 1e-7)  # 조정된 학습률로 파라미터를 업데이트합니다.

class RMSprop:
    """RMSprop"""

    def __init__(self, lr=0.01, decay_rate=0.99):
        self.lr = lr  # RMSprop 클래스의 객체가 생성될 때 학습률(lr)을 초기화합니다.
        self.decay_rate = decay_rate  # 감쇠율(decay_rate)을 초기화합니다.
        self.h = None  # RMSprop에서 사용할 h 변수를 None으로 초기화합니다.

    def update(self, params, grads):
        if self.h is None:
            self.h = {}
            for key, val in params.items():
                self.h[key] = np.zeros_like(val)  # 처음 업데이트 시 각 파라미터에 대응하는 h를 0으로 초기화합니다.
        for key in params.keys():
            self.h[key] *= self.decay_rate  # h를 감쇠율로 감소시킵니다.
            self.h[key] += (1 - self.decay_rate) * grads[key] * grads[key]  # 현재 기울기의 제곱을 h에 누적합니다.
            params[key] -= self.lr * grads[key] / (np.sqrt(self.h[key]) + 1e-7)  # 조정된 학습률로 파라미터를 업데이트합니다.

class Adam:
    """Adam (http://arxiv.org/abs/1412.6980v8)"""

    def __init__(self, lr=0.001, beta1=0.9, beta2=0.999):
        self.lr = lr  # Adam 클래스의 객체가 생성될 때 학습률(lr)을 초기화합니다.
        self.beta1 = beta1  # 1차 모멘텀 추정치에 대한 지수 감쇠율을 초기화합니다.
        self.beta2 = beta2  # 2차 모멘텀 추정치에 대한 지수 감쇠율을 초기화합니다.
        self.iter = 0  # Adam 최적화를 위한 반복 횟수(iter)를 0으로 초기화합니다.
        self.m = None  # 1차 모멘텀 추정치를 저장할 변수를 None으로 초기화합니다.
        self.v = None  # 2차 모멘텀 추정치를 저장할 변수를 None으로 초기화합니다.

    def update(self, params, grads):
        if self.m is None:
            self.m, self.v = {}, {}
            for key, val in params.items():
                self.m[key] = np.zeros_like(val)  # 처음 업데이트 시 각 파라미터에 대응하는 1차 모멘텀 추정치(m)를 0으로 초기화합니다.
                self.v[key] = np.zeros_like(val)  # 처음 업데이트 시 각 파라미터에 대응하는 2차 모멘텀 추정치(v)를 0으로 초기화합니다.
        self.iter += 1  # 반복 횟수를 1 증가시킵니다.
        lr_t = self.lr * np.sqrt(1.0 - self.beta2 ** self.iter) / (1.0 - self.beta1 ** self.iter)  # 시간에 따라 조정된 학습률을 계산합니다.
        for key in params.keys():
            self.m[key] += (1 - self.beta1) * (grads[key] - self.m[key])  # 1차 모멘텀 추정치를 업데이트합니다.
            self.v[key] += (1 - self.beta2) * (grads[key]**2 - self.v[key])  # 2차 모멘텀 추정치를 업데이트합니다.
            params[key] -= lr_t * self.m[key] / (np.sqrt(self.v[key]) + 1e-7)  # 조정된 학습률과 1차, 2차 모멘텀 추정치를 사용하여 파라미터를 업


# coding: utf-8
import sys, os

sys.path.append("C:\\Users\\wkdal\\Desktop\\All_File\\2023\\03. 수업\\딥러닝 프로그래밍\\deep-learning-from-scratch-master")

import numpy as np
import matplotlib.pyplot as plt
from collections import OrderedDict
from common.optimizer import *  # 공통 최적화 모듈에서 모든 클래스 및 함수 가져오기


# 두 변수 함수 정의
def f(x, y):
    return x ** 2 / 20.0 + y ** 2


# 위 함수의 도함수(미분) 정의
def df(x, y):
    return x / 10.0, 2.0 * y


# 초기 위치 설정
init_pos = (-7.0, 2.0)
params = {}
params['x'], params['y'] = init_pos[0], init_pos[1]
grads = {}
grads['x'], grads['y'] = 0, 0

# 최적화 방법을 저장하는 OrderedDict 생성
optimizers = OrderedDict()
optimizers["SGD"] = SGD(lr=0.95)  # 확률적 경사 하강법
optimizers["Momentum"] = Momentum(lr=0.1)  # 모멘텀
optimizers["AdaGrad"] = AdaGrad(lr=1.5)  # AdaGrad
optimizers["Adam"] = Adam(lr=0.3)  # Adam

idx = 1  # 그래프 그리기 위한 인덱스

# 각 최적화 방법에 대해 반복
for key in optimizers:
    optimizer = optimizers[key]
    x_history = []
    y_history = []
    params['x'], params['y'] = init_pos[0], init_pos[1]

    # 최적화 알고리즘 실행
    for i in range(30):
        x_history.append(params['x'])
        y_history.append(params['y'])

        grads['x'], grads['y'] = df(params['x'], params['y'])
        optimizer.update(params, grads)

    # 함수의 등고선 그리기 위한 준비
    x = np.arange(-10, 10, 0.01)
    y = np.arange(-5, 5, 0.01)

    X, Y = np.meshgrid(x, y)
    Z = f(X, Y)

    # 외곽선 단순화
    mask = Z > 7
    Z[mask] = 0

    # 최적화 경로와 함수의 등고선을 그래프에 표시
    plt.subplot(2, 2, idx)
    idx += 1
    plt.plot(x_history, y_history, 'o-', color="red")
    plt.contour(X, Y, Z)
    plt.ylim(-10, 10)
    plt.xlim(-10, 10)
    plt.plot(0, 0, '+')
    plt.title(key)
    plt.xlabel("x")
    plt.ylabel("y")

plt.show()  # 그래프 표시
