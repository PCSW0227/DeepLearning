# coding: utf-8
import os
import sys

sys.path.append("C:\\Users\\wkdal\\Desktop\\All_File\\2023\\03. 수업\\딥러닝 프로그래밍\\deep-learning-from-scratch-master\\dataset")  # 현재 스크립트가 있는 디렉토리의 부모 디렉토리를 시스템 경로에 추가
import numpy as np
import matplotlib.pyplot as plt
from dataset.mnist import load_mnist  # MNIST 데이터셋 로드를 위한 함수 임포트
from common.multi_layer_net import MultiLayerNet  # 다층 신경망 구현을 위한 클래스 임포트
from common.optimizer import SGD  # SGD 최적화 클래스 임포트

(x_train, t_train), (x_test, t_test) = load_mnist(normalize=True)  # MNIST 데이터셋을 로드하고 정규화

# 오버피팅을 재현하기 위해 학습 데이터 수를 줄임
x_train = x_train[:300]
t_train = t_train[:300]

# 가중치 감쇠 설정
#weight_decay_lambda = 0  # 가중치 감쇠를 사용하지 않을 경우
weight_decay_lambda = 0.1  # 가중치 감쇠를 사용할 경우

# 신경망 구성
network = MultiLayerNet(input_size=784, hidden_size_list=[100, 100, 100, 100, 100, 100], output_size=10,
                        weight_decay_lambda=weight_decay_lambda)
optimizer = SGD(lr=0.01)  # 학습률이 0.01인 SGD 최적화 알고리즘 사용

max_epochs = 201  # 최대 에폭 수 설정
train_size = x_train.shape[0]  # 훈련 데이터 크기
batch_size = 100  # 배치 크기

# 훈련 및 테스트 정확도를 저장할 리스트
train_loss_list = []
train_acc_list = []
test_acc_list = []

iter_per_epoch = max(train_size / batch_size, 1)  # 에폭 당 반복 횟수
epoch_cnt = 0  # 에폭 카운트

# 훈련 시작
for i in range(1000000000):
    batch_mask = np.random.choice(train_size, batch_size)  # 무작위 배치 선택
    x_batch = x_train[batch_mask]  # 배치 데이터
    t_batch = t_train[batch_mask]  # 배치 라벨

    grads = network.gradient(x_batch, t_batch)  # 기울기 계산
    optimizer.update(network.params, grads)  # 매개변수 업데이트

    if i % iter_per_epoch == 0:
        train_acc = network.accuracy(x_train, t_train)  # 훈련 데이터 정확도 계산
        test_acc = network.accuracy(x_test, t_test)  # 테스트 데이터 정확도 계산
        train_acc_list.append(train_acc)  # 정확도 저장
        test_acc_list.append(test_acc)  # 정확도 저장

        print("epoch:" + str(epoch_cnt) + ", train acc:" + str(train_acc) + ", test acc:" + str(test_acc))

        epoch_cnt += 1
        if epoch_cnt >= max_epochs:
            break

# 그래프 그리기
markers = {'train': 'o', 'test': 's'}
x = np.arange(max_epochs)
plt.plot(x, train_acc_list, marker='o', label='train', markevery=10)
plt.plot(x, test_acc_list, marker='s', label='test', markevery=10)
plt.xlabel("epochs")
plt.ylabel("accuracy")
plt.ylim(0, 1.0)
plt.legend(loc='lower right')
plt.show()
