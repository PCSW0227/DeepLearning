#이 코드는 합성곱 신경망에서의 합성곱 계층(Convolution layer)을 구현한 것입니다. 클래스 Convolution은 초기화 시
# 가중치(W), 편향(b), 스트라이드(stride), 패딩(pad)을 설정하고,
# forward 메서드를 통해 입력 데이터에 대한 합성곱 연산을 수행합니다.
import numpy as np

class Convolution:
    def __init__(self,W,b, stride=1,pad=0):
        self.W = W            # 가중치(필터)
        self.b = b            # 편향
        self.stride = stride   # 스트라이드 값
        self.pad = pad   # 패딩 값
    def forward(self,x):
        FN, C, FH, FW = self.W.shape  # 필터의 개수, 채널 수, 필터 높이, 너비
        N,C,H,W = x.shape              # 입력 데이터의 배치 크기, 채널 수, 높이, 너비
        out_h = int(1+(H+2*self.pad - FH) / self.stride)   # 출력 데이터의 높이 계산
        out_w = int(1+(W+2*self.pad - FW) / self.stride)    # 출력 데이터의 너비 계산

        col = im2col(x, FH, FW, self.stride, self.pad)     # 입력 데이터를 2차원 배열로 변환
        col_W = self.W.reshape(FN, -1).T                  # 필터를 2차원 배열로 변환
        out = np.dot(col, col_W)+self.b                   # 합성곱 연산 수행 및 편향 추가

        out = out.reshape(N, out_h, out_w, -1).transpose(0,3,1,2)    # 결과를 적절한 형태로 변환

        return out   # 합성곱 연산의 결과 반환

#요약
#Convolution 클래스는 합성곱 계층을 나타내며, 필터(W), 편향(b), 스트라이드(stride), 패딩(pad)을 이용해 초기화됩니다.
#forward 메서드는 입력 데이터 x에 대해 합성곱 연산을 수행합니다.
#입력 데이터는 im2col 함수를 이용해 2차원 배열로 변환되며, 필터도 2차원 배열로 변환됩니다.
#np.dot을 사용해 합성곱 연산이 수행되고, 결과에 편향이 추가됩니다.
#최종 결과는 적절한 형태로 변환되어 반환됩니다.
#이 클래스는 합성곱 신경망의 핵심 구성 요소 중 하나로, 이미지 인식 및 분류에 널리 사용됩니다.