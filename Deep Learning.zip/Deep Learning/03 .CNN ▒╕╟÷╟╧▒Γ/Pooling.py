#이 코드는 합성곱 신경망에서의 풀링 계층(Pooling layer)을 구현한 것입니다.
# 클래스 Pooling은 초기화 시 풀링의 크기(pool_h, pool_w), 스트라이드(stride), 패딩(pad)을 설정하고,
# forward 메서드를 통해 입력 데이터에 대한 "풀링 연산"을 수행합니다.

import numpy as np

class Pooling:
    def __init__(self,pool_h,pool_w, stride=1, pad=0):
        self.pool_h = pool_h  # 풀링 윈도우의 높이
        self.pool_w = pool_w  # 풀링 윈도우의 너비
        self.stride = stride  #  스트라이드 값
        self.pad = pad        # 패딩 값

    def forward(self,x):
        N,C,H,W = x.shape  # 입력 데이터의 배치 크기, 채널 수, 높이, 너비
        out_h = int(1+(H-self.pool_h)/self.stride)   # 출력 데이터의 높이 계산
        out_w = int(1+(w-self.pool_w)/self.stride)    # 출력 데이터의 너비 계산

        # 전개 1
        col = im2col(x, self.pool_h, self.pool_w, self.stride, self.pad)    # 입력 데이터를 2차원 배열로 변환
        col = col.reshape(-1,self.pool_h*self.pool_w)    # 풀링 연산을 위해 형태 변환

        # 최대값 2
        out = np.max(col, axis = 1)   # 각 풀링 윈도우에서 최대값을 계산

        # 성형 3
        out = out.reshape(N, out_h, out_w, C).transpose(0,3,1,2)    # 결과를 적절한 형태로 변환


        return out


#요약
#Pooling 클래스는 풀링 계층을 나타내며, 풀링 윈도우 크기(pool_h, pool_w), 스트라이드(stride), 패딩(pad)을 이용해 초기화됩니다.
#forward 메서드는 입력 데이터 x에 대해 풀링 연산을 수행합니다.
#입력 데이터는 im2col 함수를 이용해 2차원 배열로 변환되며, 이 배열은 풀링 연산을 위해 재구성됩니다.
#각 풀링 윈도우에서 최대값을 찾아내는 최대 풀링(max pooling) 연산을 수행합니다.
#최종 결과는 적절한 형태로 변환되어 반환됩니다.
#이 클래스는 이미지의 공간적 크기를 줄이면서 중요한 특징을 유지하는 데 도움이 되며, 합성곱 신경망에서 중요한 역할을 합니다.