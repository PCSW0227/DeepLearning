class SimpleConvNet:
    # 초기화 메서드
    def __init__(self, input_dim=(1, 28, 28),
                 conv_param={'filter_num': 30, 'filter_size': 5, 'pad': 0, 'stride': 1},
                 hidden_size=100, output_size=10, weight_init_std=0.01):
        # 합성곱 계층의 매개변수 초기화
        filter_num = conv_param['filter_num']  # 필터 개수
        filter_size = conv_param['filter_size']  # 필터 크기
        filter_pad = conv_param['pad']  # 패딩
        filter_stride = conv_param['stride']  # 스트라이드
        input_size = input_dim[1]  # 입력 데이터의 크기

        # 합성곱 계층의 출력 크기 계산
        conv_output_size = (input_size - filter_size + 2 * filter_pad) / filter_stride + 1
        pool_output_size = int(filter_num * (conv_output_size / 2) * (conv_output_size / 2))

        # 가중치 매개변수 초기화
        self.params = {}
        self.params['W1'] = weight_init_std * np.random.randn(filter_num, input_dim[0], filter_size, filter_size)  # 1번째 계층의 가중치
        self.params['b1'] = np.zeros(filter_num)  # 1번째 계층의 편향
        self.params['W2'] = weight_init_std * np.random.randn(pool_output_size, hidden_size)  # 2번째 계층의 가중치
        self.params['b2'] = np.zeros(hidden_size)  # 2번째 계층의 편향
        self.params['W3'] = weight_init_std * np.random.randn(hidden_size, output_size)  # 3번째 계층의 가중치
        self.params['b3'] = np.zeros(output_size)  # 3번째 계층의 편향

        # CNN을 구성하는 계층들 생성
        from collections import OrderedDict
        self.layers = OrderedDict()
        self.layers['Conv1'] = Convolution(self.params['W1'], self.params['b1'], conv_param['stride'], conv_param['pad'])  # 합성곱 계층
        self.layers['Relu1'] = Relu()  # 활성화 함수 계층 (ReLU)
        self.layers['Pool1'] = Pooling(pool_h=2, pool_w=2, stride=2)  # 풀링 계층
        self.layers['Affine1'] = Affine(self.params['W2'], self.params['b2'])  # 완전 연결 계층 (Affine)
        self.layers['Affine2'] = Affine(self.params['W3'], self.params['b3'])  # 또 다른 완전 연결 계층 (Affine)
        self.last_layer = SoftmaxWithLoss()  # 손실 계층 (Softmax with Loss)

    # 예측 메서드
    def predict(self, x):
        for layer in self.layers.values():
            x = layer.forward(x)  # 각 계층을 순서대로 순전파
        return x

    # 손실 함수 계산 메서드
    def loss(self, x, t):
        y = self.predict(x)  # 예측 값 계산
        return self.last_layer.forward(y, t)  # 손실 계산

    # 오차역전파를 이용한 기울기 계산 메서드
    def gradient(self, x, t):
        # 순전파
        self.loss(x, t)
        # 역전파
        dout = 1
        dout = self.last_layer.backward(dout)  # 손실 계층 역전파

        layers = list(self.layers.values())
        layers.reverse()  # 계층을 역순으로 정렬
        for layer in layers:
            dout = layer.backward(dout)  # 각 계층을 역순으로 역전파

        # 결과 저장
        grads = {}
        grads['W1'] = self.layers['Conv1'].dW  # 1번째 계층 가중치의 기울기
        grads['b1'] = self.layers['Conv1'].db  # 1번째 계층 편향의 기울기
        grads['W2'] = self.layers['Affine1'].dW  # 2번째 계층 가중치의 기울기
        grads['b2'] = self.layers['Affine1'].db  # 2번째 계층 편향의 기울기
        grads['W3'] = self.layers['Affine2'].dW  # 3번째 계층 가중치의 기울기
        grads['b3'] = self.layers['Affine2'].db  # 3번째 계층 편향의 기울기

        return grads

#요약
#이 클래스는 CNN의 기본 구조를 구현하며, 이미지 인식 및 분류 작업에 사용됩니다.
#순전파(predict), 손실 계산(loss), 역전파(gradient) 메서드를 포함합니다.
#각 계층의 순서와 기능은 이미지 데이터의 특징을 효과적으로 추출하고 분류하기 위해 중요합니다.