# Relu 클래스는 mask라는 인스턴스 변수를 가진다. mask는 True/False로 구성된 넘파이 배열이다.
# 이 배열로 순전파의 입력인 x의 원소 값이 0 이하인 인덱스는 True, 0 이상이면 False

class Relu :
    def __init__(self):
        self.mask = None

    def forward(self, x):
        self.mask = (x <= 0)
        out = x.copy()
        out[self.mask] = 0

        return out

    def backward(self, dout):
        dout[self.mask] = 0
        dx = dout

        return dx

import numpy as np
# 예컨대 mask 변수는 다음 예와 같이 True/False로 구성된 넘파이 배열을 유지한다.
x = np.array([[1.0, -0.5],[-2.0,3.0]])
print(x)
mask = (x<=0)
print(mask )