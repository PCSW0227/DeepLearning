class MulLayer:              # 클래스 이름: MulLayer는 곱셈을 수행하는 계층을 나타냅니다.
    def __init__(self):      # __init__ 메서드: 클래스의 인스턴스가 생성될 때 호출되며, x와 y 변수를 초기화합니다.
                             # 이 변수들은 순전파 시의 입력값을 유지하기 위해 사용됩니다.
        self.x = None
        self.y = None

    def forward(self, x, y): # forward 메서드: 순전파를 수행합니다. x와 y를 인자로 받아 두 값을 곱한 후 결과를 반환합니다.
        self.x = x           # 입력값 x를 인스턴스 변수에 저장합니다.
        self.y = y           # 입력값 y를 인스턴스 변수에 저장합니다.
        out = x * y          # 두 입력값을 곱합니다.

        return out           # 곱한 결과를 반환합니다.

    def backward(self, dout):# backward 메서드: 역전파를 수행합니다. 상류에서 넘어온 미분값(dout)을 받습니다.
        dx = dout * self.y   # x에 대한 미분을 계산합니다. 순전파 때의 y값과 상류의 미분값을 곱합니다.
        dy = dout * self.x   # y에 대한 미분을 계산합니다. 순전파 때의 x값과 상류의 미분값을 곱합니다.
        return dx, dy        # 계산된 미분값들을 반환합니다.



class AddLayer:
    def __init__(self):
        pass
    def forward(self, x,y):
        out = x + y
        return out
    def backward(self, dout):
        dx = dout *1
        dy = dout *1
        return dx, dy

apple = 100
apple_num = 2
orange = 150
orange_num = 3
tax = 1.1

# 계층들
mul_apple_layer = MulLayer()
mul_orange_layer = MulLayer()
add_apple_orange_layer = AddLayer()
mul_tax_layer = MulLayer()

# 순전파
apple_price = mul_apple_layer.forward(apple, apple_num)
orange_price = mul_orange_layer.forward(orange, orange_num)
all_price = add_apple_orange_layer.forward(apple_price, orange_price)
price = mul_tax_layer.forward(all_price, tax)

# 역전파
dprice = 1
dall_price, dtax = mul_tax_layer.backward(dprice)
dapple_price, dorange_price = add_apple_orange_layer.backward(dall_price)
dorange, dorange_num = mul_orange_layer.backward(dorange_price)
dapple, dapple_num = mul_apple_layer.backward(dapple_price)

print(price)
print(dapple_num, dapple, dorange, dorange_num, dtax)






