# 신경망 순전파의 흐름
import numpy as np

x = np.random.rand(2)   #입력
w = np.random.rand(2,3) #가중치
b = np.random.rand(3)   #편향

x.shape #(2,)
w.shape #(2,3)
b.shape #(3,)

y = np.dot(x,w) + b
#여기에서 x, w, b는 각각 형상이 (2,)(2,3)(3,)인 다차원 배열이다.
# 그러면 뉴런의 가중치의 합은 y = np.dot(x,w) + b  처럼 계산한다.
# 그리고 이 y를 활성화 함수로 변환해 다음 층으로 전파하는 것이 신경망 순전파의 흐름이다.